export const DeviationPanelAsync = () => import('./DeviationPanel.vue');
