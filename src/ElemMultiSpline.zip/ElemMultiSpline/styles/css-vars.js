export const cssVars = {
    'breadcrumb_left': 'breadcrumb.left',
    'breadcrumb_top': 'breadcrumb.top',
    'breadcrumb_bottom': 'breadcrumb.bottom',
    'breadcrumb_right': 'breadcrumb.right',
    'breadcrumb_font-size': 'breadcrumb.fontSize',
    'breadcrumb_color': 'breadcrumb.color',
    'breadcrumb_font-family': 'breadcrumb.fontFamily',
    'breadcrumb_font-weight': 'breadcrumb.fontWeight',
};
