/**
 * @type {import('./ElemFilter').TElemInstance}
 */
export const ElemInstanceTypeDescriptor = undefined;

/**
 * @typedef {import('./ElemFilter').TInstance} TInstance
 * @type {TInstance}
 */
export const PanelInstanceTypeDescriptor = undefined;
