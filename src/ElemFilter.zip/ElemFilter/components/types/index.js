/**
 * @type {import('./FilterHeader').TFilterHeaderInstance}
 */
export const FilterHeaderInstanceTypes = undefined;