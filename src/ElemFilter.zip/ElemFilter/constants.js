export const TOGGLE_MENU_DELAY = 300;
export const EMPTY_FIELD_URL = '';
