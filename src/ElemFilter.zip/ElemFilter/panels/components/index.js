export { default as UiBtnSettings } from './BtnSettings.vue';
