/**
 * FontSize extension for Tiptap
 *
 * Adds font-size support via TextStyle mark.
 * Usage: editor.chain().focus().setFontSize('16px').run()
 */

import { Extension } from '@tiptap/core';

const FontSize = Extension.create({
    name: 'fontSize',

    addOptions() {
        return {
            types: ['textStyle']
        };
    },

    addGlobalAttributes() {
        return [
            {
                types: this.options.types,
                attributes: {
                    fontSize: {
                        default: null,
                        parseHTML: element => element.style.fontSize?.replace(/['"]+/g, ''),
                        renderHTML: attributes => {
                            if (attributes.fontSize == null) {
                                return {};
                            }

                            return {
                                style: `font-size: ${attributes.fontSize}`
                            };
                        }
                    }
                }
            }
        ];
    },

    addCommands() {
        return {
            setFontSize: fontSize => ({ chain }) => chain()
                    .setMark('textStyle', { fontSize })
                    .run(),
            unsetFontSize: () => ({ chain }) => chain()
                    .setMark('textStyle', { fontSize: null })
                    .removeEmptyTextStyle()
                    .run()
        };
    }
});

export default FontSize;
