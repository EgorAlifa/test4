const nextId = (prefix) => `${prefix}-${nanoid()}`;
const Position = {
    LEFT: 'left',
    RIGHT: 'right',
    TOP: 'top',
    BOTTOM: 'bottom',
    START: 'start',
    END: 'end'
};
import { nanoid } from 'nanoid';

export default {
    props: {
        /**
         * z-index
         */
        zIndex: {
            type: Number,
            default: 1010
        },
        /**
         * Dropdown append to body
         */
        appendToBody: {
            type: Boolean,
            default: true
        },
        /**
         * Position, values of the popover:
         * bl, br, tl, tr - bottom-left, bottom-right, top-left, top-right
         * @values bl, br, tl, tr, top, top-start, top-end, left, left-start, left-end, right, right-start, right-end, bottom, bottom-start, bottom-end
         */
        position: {
            type: String,
            default: `${Position.BOTTOM}-${Position.START}`
        },
        /**
         * Position offset [ x, y ] where:
         * x - skidding (offset along target)
         * y - distance (offset away from target)
         */
        positionOffset: {
            type: Array,
            default() {
                return [1, 1];
            }
        },
        /**
         * Auto width
         */
        autoWidth: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            popoverShow: false,
            popoverTargetId: nextId('popover-target')
        };
    },
    computed: {
        popoverTarget() {
            return `[data-popover=${this.popoverTargetId}]`;
        },
        popoverOptions() {
            let { zIndex, appendToBody, position, positionOffset, autoWidth, popoverTarget: target } = this;
            return {
                zIndex,
                appendToBody,
                position,
                positionOffset,
                autoWidth,
                target
            };
        }
    },
    methods: {
        togglePopover() {
            this.popoverShow = !this.popoverShow;
        }
    }
};
