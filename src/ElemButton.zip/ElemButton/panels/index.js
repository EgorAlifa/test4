export default [
    () => import('./OptionsPanel.vue'),
    () => import('./BufferCopyPanel.vue'),
    () => import('./StylesPanel.vue'),
    () => import('./AppearancePanel.vue')
];
