export const POPUP_LIFETIME = 2000;
