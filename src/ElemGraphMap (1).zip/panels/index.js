export { DatasetPanelMixin } from './DatasetPanelMixin';

export default [() => import('./SettingsPanel.vue')];
