/**
 * @typedef {import('../ElemGraphMap.vue').default} TInstance
 * @type {TInstance}
 */
export const ElemInstanceTypeDescriptor = undefined;
/**
 * @typedef {import('../panels/SettingsPanel.vue').default} TPanelInstance
 * @type {TPanelInstance}
 */
export const PanelInstanceTypeDescriptor = undefined;
