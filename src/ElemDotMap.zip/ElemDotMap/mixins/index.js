import ControlMixin from './ControlMixin';
import AdditionalDremioMixin from './AdditionalDremioMixin';
import Unit2PxMixin from './Unit2PxMixin';

export default [ControlMixin, AdditionalDremioMixin, Unit2PxMixin];
