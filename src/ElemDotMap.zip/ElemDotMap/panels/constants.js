export const DEFAULT_DRAG_OPTIONS = Object.freeze({
    animation: 200,
    handle: '.drag-handle'
});
