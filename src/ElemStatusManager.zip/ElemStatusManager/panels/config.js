import { WorkMode } from '../constants';

export const WorkModeOptions = [
    { value: WorkMode.STANDARD, label: 'Стандартный' },
    { value: WorkMode.SELECT, label: 'Селект' }
];
