export const StatusCssVars = Object.freeze({
    status_color: 'color'
});
