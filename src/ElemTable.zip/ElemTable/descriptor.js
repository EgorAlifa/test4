/* eslint-disable no-restricted-syntax */
import panels from './panels';
import { cssVars } from './css-vars';

/**
 * @enum {string}
 * @type {Readonly<Record<string, string>>}
 */
export const Vars = Object.freeze({});

/**
 * @description Don't change `descriptor` exported name
 * @return {ElemDescriptor}
 */
export const descriptor = () => ({
    props: {
        dremio: {
            type: Object,
            default: null
        },
        rowPreset: {
            type: Object,
            default: () => ({
                shouldChooseFirst: false,
                dataField: null,
                value: null
            })
        },
        isWaitingForState: {
            type: Boolean,
            default: false
        },
        zebraStyle: {
            type: Object,
            default: () => ({
                isShown: false,
                color: null,
                bgColor: null
            })
        },
        shouldDisplaySkeleton: {
            type: Boolean,
            default: true
        },
        fieldToSelectFilter: {
            type: String,
            default: null
        },
        fieldToApplyFilter: {
            type: String,
            default: null
        },
        canMultipleSelect: {
            type: Boolean,
            default: false
        },
        cardsMode: {
            type: Object,
            default: () => ({
                isEnabled: false,
                card: {
                    width: null,
                    height: null
                },
                gap: [null, null],
                columnCount: 1
            })
        },
        height: {
            type: String,
            default: '100'
        },
        routeQueryParamNames: {
            type: Array,
            default: () => []
        },
        resultRow: {
            type: Object,
            default: () => ({
                isEnabled: false,
                position: 'bottom'
            })
        },
        metricForSelect: {
            type: String,
            default: null
        }
    },
    vars: Object.values(Vars).reduce((acc, varName) => ({ ...acc, [varName]: { description: varName } }), {})
});

export const meta = {
    descriptor,
    panels,
    slotNames: ['default', 'header', 'footer', 'resultRow'],
    isChildAllowed() {
        return this.props.dremio != null;
    },
    cssVars
};

export default descriptor;
