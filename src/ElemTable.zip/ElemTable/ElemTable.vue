<template>
    <w-elem>
        <button v-if="canAnyDimensionStateGoPrev" class="btn btn-inline pull-right" @click="anyDimensionStateGoPrev">
            <i class="mdi mdi-undo"></i>
        </button>

        <w-table :is-loading="loading" :is-cards-mode="props.cardsMode.isEnabled">
            <template #header>
                <slot name="header"><code v-if="isEditorMode">Header slot</code></slot>
            </template>
            <template #default>
                <div class="d-flex flex-col">
                    <div :class="{ 'cards-grid': props.cardsMode.isEnabled }">
                        <w-data-aggregator
                            v-for="(rowData, rowIndex) of dataRows"
                            :key="rowIndex"
                            v-bind="{ rowData, rowIndex, fieldToSelectFilter: props.fieldToSelectFilter }">
                            <slot>
                                <code v-if="isEditorMode">Data slot</code>
                            </slot>
                        </w-data-aggregator>
                    </div>

                    <div v-if="props.resultRow.isEnabled" class="result-row w-100" data-slot="resultRow">
                        <slot name="resultRow">
                            <code v-if="isEditorMode">Result slot</code>
                        </slot>
                    </div>
                </div>
            </template>
            <template #footer>
                <slot name="footer"><code v-if="isEditorMode">Footer slot</code></slot>
            </template>

            <template #preload>
                <w-table-skeleton
                    v-if="props.shouldDisplaySkeleton"
                    :rows-count="limit"
                    :columns-count="dimensionMetricNames.length" />
                <div v-else class="shim">
                    <div class="shim-content d-flex flex-center h-100">
                        <div class="preloader color-blue"></div>
                    </div>
                </div>
            </template>
        </w-table>

        <template v-if="isEditorMode">
            <div v-if="!props.dremio" class="alert alert-warn">
                <div class="alert-body text-small">Query schema not defined.</div>
            </div>
        </template>
    </w-elem>
</template>
<script>
import { Elem, Dremio } from '@goodt-wcore/core';
import { useDremio } from '@goodt-common/dremio';
import { Url } from '@goodt-common/utils';
import { StoreManager } from '@goodt-wcore/managers';
import { useRouteQueryManager } from '@goodt-wcore/utils';
import { isEmpty, pick, zipObject, zip, at } from 'lodash';

import { useTable, ControlType } from '../shared';
import { meta } from './descriptor';
import { ElemInstanceTypeDescriptor } from './types';
import { Table as WTable, DataAggregator as WDataAggregator, TableSkeleton as WTableSkeleton } from './components';
import { buildTableChildren, filterOrExtendWith, sortMetricsByType } from './utils';

const { Query } = Dremio;
const { addRouteQueryParams } = useRouteQueryManager();
const { store, ValueObject } = StoreManager;

export default {
    extends: Elem,
    components: { WTable, WDataAggregator, WTableSkeleton },
    mixins: [useTable(), useDremio().mixin],
    inject: {
        $setElemChildren: {
            default: null
        },
        $createEntity: {
            default: null
        },
        childTable: {
            default: null
        }
    },
    meta,
    data: (vm) => ({
        /**
         * @property {Record<string, any>[]}
         */
        selectedRows: [],
        /**
         * @public
         * @property {Record<string, () => {}>}
         */
        loadDataHooks: {
            before: vm.onLoadDataHookBefore,
            then: vm.onLoadDataHookThen
        },
        /**
         * @property {string[]}
         */
        checkedFormControls: [],
        /* Vetur HACK */
        ...ElemInstanceTypeDescriptor
    }),
    computed: {
        /**
         * @public
         * @return string[]
         */
        dimensionMetricNames() {
            const { query, dimensionList } = this.queryHelper;
            return [...Query.queryMetricNames(query), ...Object.keys(dimensionList)];
        },
        /**
         * @return Record<string, any>[]
         */
        dataRows() {
            return this.result?.rows ?? [];
        },
        /**
         * @return boolean
         */
        canAnyDimensionStateGoPrev() {
            const { queryHelper } = this;

            if (queryHelper == null) {
                return false;
            }

            return Object.keys(queryHelper.dimensionList).some(
                (name) => queryHelper.dimensionStateExists(name) && queryHelper.dimensionStateIsFirst(name) === false
            );
        }
    },
    methods: {
        setSelectedRowsByDataValues(state) {
            const { metricForSelect, canMultipleSelect } = this.props;

            const stateMetrics = Object.entries(state).filter(([key]) => key === metricForSelect);
            this.selectedRows = this.dataRows.filter((row) =>
                stateMetrics.some(([key, value]) => {
                    if (value == null) {
                        return false;
                    }

                    let adaptValue = value;

                    if (Array.isArray(value)) {
                        adaptValue = canMultipleSelect ? value : value[0];
                    }

                    return String(adaptValue).includes(row[key]);
                })
            );
        },
        /**
         * @public
         * Store state watcher handler
         * @param {object} state
         */
        storeStateWatcher(state) {
            if (Object.keys(state).length === 0) {
                return;
            }

            const { metricForSelect } = this.props;

            const newState = Object.fromEntries(Object.entries(state).filter(([key]) => key !== metricForSelect));

            if (metricForSelect != null) {
                this.setSelectedRowsByDataValues(state);
            }

            this.$nextTick(() => {
                if (this.applyDremioFilters(newState)) {
                    this.offset = 0;
                    this.loadData();
                }
            });
        },
        /**
         * @param {() => {}} cancel
         */
        onLoadDataHookBefore(cancel) {
            const {
                $storeState,
                childTable,
                props: { isWaitingForState, fieldToApplyFilter }
            } = this;
            const isEmptyStore = isEmpty($storeState) || Object.values($storeState).every(Boolean) === false;
            const shouldHideTable = isWaitingForState && isEmptyStore;

            if (shouldHideTable) {
                this.result = null;
                cancel();
                return;
            }

            if (childTable?.filter != null && fieldToApplyFilter != null) {
                this.applyDremioFilters({ [fieldToApplyFilter]: childTable.filter });
            }

            this.loading = true;
        },
        /**
         * @param {DremioResult} result
         */
        onLoadDataHookThen({ rows = [] }) {
            if (rows.length === 0) {
                return;
            }

            const { shouldChooseFirst, dataField, value } = this.props.rowPreset;
            const { metricForSelect } = this.props;

            if (shouldChooseFirst) {
                this.selectedRows = [rows[0]];
                return;
            }

            this.selectedRows = [...(rows.find(({ [dataField]: fieldValue }) => fieldValue === value) ?? [])];
            if (metricForSelect != null) {
                this.setSelectedRowsByDataValues(this.$storeState);
            }
        },
        /**
         * @public
         * @param {string} dataField
         * @param {any} value
         * @param {string} controlType
         */
        toggleFormControl({ dataField, value, controlType }) {
            const isCheckbox = controlType === ControlType.CHECKBOX;
            this.checkedFormControls = filterOrExtendWith(this.checkedFormControls, value, isCheckbox, false);
            this.$storeCommit({ [dataField]: isCheckbox ? this.checkedFormControls : value });
        },
        /**
         * @param {number} page = 1
         */
        loadDataPage(page = 1) {
            this.page = page;
            this.loadData();
        },
        /**
         * @public
         * @param {Record<string, any>} row
         */
        setSelectedRow(row) {
            const { canMultipleSelect } = this.props;
            this.selectedRows = filterOrExtendWith(this.selectedRows, row, canMultipleSelect);
        },
        /**
         * @public
         * @param {{sourceVars: string[], userVarsMap: Record<string, any>}} varsToCommit
         * @param {string[]} events
         * @param {Record<string, any>} [link={}]
         */
        runActions({ varsToCommit, events, link = {} }) {
            this.commit(varsToCommit);
            events.forEach(this.$eventTrigger);

            const { url: path, query, isTargetBlank, queryMetrics } = link;
            this.navigate({ path, query: { ...query, ...queryMetrics } }, isTargetBlank);
            this.addRouteQueryParams();
        },
        /**
         * @param {string[]} sourceVars
         * @param {Record<string, any>} userVarsMap
         */
        commit({ sourceVars, userVarsMap }) {
            if (isEmpty(userVarsMap) === false) {
                this.$storeCommit(userVarsMap, { global: true });
            }

            if (sourceVars.length === 0) {
                return;
            }

            const { selectedRows, props } = this;
            const { canMultipleSelect } = props;

            if (canMultipleSelect) {
                /*
                 * если мультиселект - собираем из массива this.selectedRows объект для отправки
                 * this.selectedRows пустой? Ресетим соответствующие varsFromSource переменные в хранилище
                 */
                const dataToCommit =
                    selectedRows.length > 0
                        ? zipObject(sourceVars, zip(...selectedRows.map((row) => at(row, sourceVars))))
                        : sourceVars.reduce((acc, variable) => ({ ...acc, [variable]: null }), {});

                this.$storeCommit(dataToCommit);
                return;
            }
            /*
             * если не мультиселект - забираем первый объект из this.selectedRows и формируем для отправки
             * Нет выбранной строки? Ресетим соответствующие varsFromSource переменные в хранилище
             */
            const [selectedRow] = selectedRows;
            const isSelectedRowExist = selectedRow != null;
            const dataToCommit = sourceVars.reduce(
                (acc, variable) => ({
                    ...acc,
                    [variable]: isSelectedRowExist ? selectedRow[variable] : null
                }),
                {}
            );

            this.$storeCommit(dataToCommit);
        },
        /**
         * @param {string} path
         * @param {Record<string, any>} query
         * @param {boolean} shouldOpenNewTab
         */
        navigate({ path, query }, shouldOpenNewTab = false) {
            if ([null, undefined, ''].includes(path)) {
                return;
            }

            const [pathBeforeHash, pathAfterHash = ''] = path?.split('#');

            const options = pathAfterHash.startsWith('/')
                ? { hash: Url.create({ href: pathAfterHash, query }).toString() }
                : { hash: pathAfterHash, query };

            const url = Url.create({ href: pathBeforeHash, ...options });

            // case '/some-path/#/route-path?id=1'
            if (url.isRelative && pathAfterHash.startsWith('/')) {
                // make url absolute
                url.host = window.location.host;
                url.protocol = window.location.protocol;
            }

            if (url.isAbsolute) {
                const target = shouldOpenNewTab === true ? '_blank' : '_self';
                window.open(url, target);
                return;
            }

            this.$routeNavigate(url);
        },
        /**
         *
         */
        anyDimensionStateGoPrev() {
            Object.keys(this.queryHelper.dimensionList).forEach((dimensionName) =>
                this.queryHelper.dimensionStateGoPrev(dimensionName)
            );
            this.loadDataPage();
        },
        /**
         * @public
         */
        generateTable() {
            const {
                queryHelper: { dimensionList, query },
                result: { schema },
                id: elemId
            } = this;
            const metrics = sortMetricsByType(Query.queryMetricNames(query), schema);
            const children = buildTableChildren(
                this.$createEntity,
                [...Object.keys(dimensionList), ...metrics],
                schema
            );

            this.$setElemChildren({ id: elemId, children });
        },
        /**
         * @public
         * @param {string} fieldName
         * @param {number} offset
         * @param {number} limit
         * @param {string} searchInput
         * @return {Promise<any>}
         */
        fetchHeaderFilterData(fieldName, { offset, limit }, searchInput) {
            const { queryHelper, dremioSdk } = this;
            const { FILTER_TYPE, KEY, SORT_TYPE } = Query;
            const query =
                searchInput === ''
                    ? Query.queryRemoveFilter(queryHelper.buildQuery(), fieldName)
                    : Query.queryInsertUpdateFilter(
                          queryHelper.buildQuery(),
                          Query.createFilter({
                              name: fieldName,
                              type: FILTER_TYPE.LIKE,
                              // eslint-disable-next-line no-restricted-syntax
                              value: [`%${searchInput}%`]
                          })
                      );
            const isDimension = Query.queryGetDimensionField(query, fieldName) !== null;
            const queryDimensions = isDimension
                ? query[KEY.DIMENSIONS].filter((dimension) => Object.keys(dimension).includes(fieldName))
                : query[KEY.DIMENSIONS];
            const queryMetrics = isDimension
                ? []
                : [query[KEY.METRICS].find((metric) => Query.getMetricName(metric) === fieldName)];

            return dremioSdk
                .getData(
                    {
                        ...query,
                        [KEY.DIMENSIONS]: queryDimensions,
                        [KEY.METRICS]: queryMetrics,
                        [KEY.SORT]: [{ [fieldName]: SORT_TYPE.ASC }]
                    },
                    offset,
                    limit
                )
                .catch(this.handleError);
        },
        /**
         * @public
         * @param {string[]|null} filter
         */
        commitHeaderFilter(filter) {
            this.$storeCommit(filter);
        },

        addRouteQueryParams() {
            const { writeMap } = this.$storeMeta.vars;
            const triggerAliases = Object.values(pick(writeMap, this.props.routeQueryParamNames));
            const pickedStoreState = pick(store.state, triggerAliases);
            const storeValues = Object.entries(pickedStoreState).reduce(
                (acc, [key, value]) => ({ ...acc, [key]: ValueObject.getValue(value) }),
                {}
            );
            addRouteQueryParams(storeValues);
        }
    }
};
</script>
<style scoped lang="pcss" src="./style.pcss"></style>
