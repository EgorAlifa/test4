<template>
    <div :style="cssStyle">
        <slot></slot>
    </div>
</template>

<script>
export default {
    inject: {
        $widget: {
            default: null
        },
        row: {
            default: null
        }
    },
    provide(vm = this) {
        return {
            get childTable() {
                return {
                    get filter() {
                        return vm.rowData?.[vm.fieldToSelectFilter] ?? null;
                    }
                };
            },
            get row() {
                return {
                    get selectedRows() {
                        return vm.row.selectedRows;
                    },
                    get isSelectedRow() {
                        return vm.row.selectedRows.includes(vm.rowData);
                    },
                    get rowIndex() {
                        return vm.rowIndex;
                    },
                    setSelectedRow: vm.row.setSelectedRow,
                    runActions: vm.row.runActions
                };
            },
            get data() {
                return {
                    get rowData() {
                        return vm.rowData;
                    }
                };
            }
        };
    },
    props: {
        /**
         * @public
         */
        rowData: {
            type: Object,
            default: () => ({})
        },
        rowIndex: {
            type: Number,
            default: 0
        },
        fieldToSelectFilter: {
            type: String,
            default: null
        }
    },
    computed: {
        widgetProps() {
            return this.$widget.props;
        },
        cssStyle() {
            const { widgetProps, rowIndex } = this;

            if (widgetProps.zebraStyle.isShown && rowIndex % 2 !== 0) {
                return {
                    backgroundColor: 'var(--w-table-zebra_bg-color)',
                    color: 'var(--w-table-zebra_color)'
                };
            }

            return null;
        }
    }
};
</script>
