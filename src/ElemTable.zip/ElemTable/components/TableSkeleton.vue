<template functional>
    <table class="table table-borders w-100">
        <tbody>
            <tr v-for="i of props.rowsCount || 3" :key="i">
                <td v-for="j of props.columnsCount || 3" :key="j">
                    <div class="skeleton"></div>
                </td>
            </tr>
        </tbody>
    </table>
</template>
<script>
export default {
    props: {
        rowsCount: {
            type: Number
        },
        columnsCount: {
            type: Number
        }
    }
};
</script>
