export const AREA = 'area';
export const FRACTION = '1fr';
export const GAP = '0px';

/**
 * @enum {string}
 * @type {Readonly<Record<string, string>>}
 */
export const TableSlot = Object.freeze({
    HEADER: 'header',
    FOOTER: 'footer'
});

/**
 * @enum {string}
 * @type {Readonly<Record<string, string>>}
 */
export const WidgetType = Object.freeze({
    GRID_LAYOUT: 'basic::ElemGridLayout',
    TABLE_HEADER: 'insight::Table/ElemHeader',
    TABLE_PAGINATOR: 'insight::Table/ElemPaginator',
    TABLE_ROW: 'insight::Table/ElemRow',
    TABLE_CELL: 'insight::Table/ElemValue'
});

/**
 * @enum {string}
 * @type {Readonly<Record<string, string>>}
 */
export const FieldDataType = Object.freeze({
    VARCHAR: 'VARCHAR',
    DOUBLE: 'DOUBLE',
    INTEGER: 'INTEGER'
});
