/* place render data: texts, ui control settings, options lists, css class and styles map here */
