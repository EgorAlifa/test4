export const SizeOptions = [{ value: null, label: 'inherit' }];

export const ResultRowPositionOptions = [
    { value: 'top', label: 'Сверху' },
    { value: 'bottom', label: 'Снизу' }
];
