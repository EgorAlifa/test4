import { DremioPanelAsync } from '@goodt-common/dremio-panels';
const SettingsPanelAsync = () => import('./SettingsPanel.vue');

export * from './config';
export default [DremioPanelAsync, SettingsPanelAsync];
