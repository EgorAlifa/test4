import { merge } from 'lodash';
import { descriptor as ElemHeaderDescriptor } from '../ElemHeader/descriptor';
import { descriptor as ElemValueDescriptor } from '../ElemValue/descriptor';
import { descriptor as ElemRowDescriptor } from '../ElemRow/descriptor';
import { descriptor as ElemPaginatorDescriptor } from '../ElemPaginator/descriptor';
import { AREA, WidgetType, FRACTION, GAP, TableSlot, FieldDataType } from './constants';

/**
 * @typedef {import('@goodt-wcore/core').IElemInstance} ElemInstance
 */

/**
 * @param {string} type
 * @return {boolean}
 */
const hasFieldNumberType = (type) => [FieldDataType.DOUBLE, FieldDataType.INTEGER].includes(type);

/**
 * @param {(Object) => ElemInstance} createEntity
 * @param {string[]} dataFields
 * @param {Record<string, any>[]} schema
 * @return {ElemInstance[]}
 */
export const buildTableChildren = (createEntity, dataFields, schema) => {
    const buildPropsDefault = (props) =>
        Object.fromEntries(
            Object.entries(props).map(([key, value]) =>
                typeof value.default === 'function' ? [key, value.default()] : [key, value.default]
            )
        );
    const headerPropsDefault = buildPropsDefault(ElemHeaderDescriptor().props);
    const rowPropsDefault = buildPropsDefault(ElemRowDescriptor().props);
    const cellPropsDefault = buildPropsDefault(ElemValueDescriptor().props);
    const paginatorPropsDefault = buildPropsDefault(ElemPaginatorDescriptor().props);

    const tableHeadersFactory = () =>
        dataFields.map((dataField, idx) => {
            const slot = `${AREA}-${idx}`;
            const [{ type: fieldType }] = schema.filter(({ name }) => name === dataField);

            return createEntity({
                type: WidgetType.TABLE_HEADER,
                props: merge({}, headerPropsDefault, {
                    slot,
                    dataField,
                    header: {
                        fontSize: 'var(--font-size-smaller)',
                        fontWeight: '700',
                        color: 'rgba(0, 0, 0, .5)',
                        sort: {
                            field: dataField,
                            icon: {
                                color: 'rgba(0, 0, 0, .5)'
                            }
                        },
                        hint: {
                            icon: {
                                color: 'rgba(0, 0, 0, .5)'
                            }
                        }
                    },
                    cssClass: hasFieldNumberType(fieldType) ? ['d-flex', 'flex-h-end'] : ['d-flex'],
                    cssStyle: {
                        padding: '0.375rem'
                    }
                })
            });
        });

    const tableCellsFactory = () =>
        dataFields.map((dataField, idx) => {
            const slot = `${AREA}-${idx}`;
            const [{ type: fieldType }] = schema.filter(({ name }) => name === dataField);

            return createEntity({
                type: WidgetType.TABLE_CELL,
                props: merge({}, cellPropsDefault, {
                    slot,
                    dataField,
                    style: {
                        fontSize: 'var(--font-size-smaller)',
                        fontWeight: '400',
                        color: 'rgba(19, 12, 64, 1)'
                    },
                    cssClass: hasFieldNumberType(fieldType) ? ['d-flex', 'flex-h-end'] : ['d-flex'],
                    cssStyle: {
                        padding: '0.375rem'
                    }
                })
            });
        });

    const gridLayoutFactory = ({ slot = '', children }) =>
        createEntity({
            type: WidgetType.GRID_LAYOUT,
            props: {
                slot,
                grid: {
                    areas: [dataFields.map((_, idx) => `${AREA}-${idx}`)],
                    rows: [FRACTION],
                    cols: dataFields.map(() => FRACTION),
                    gap: {
                        row: GAP,
                        col: GAP
                    }
                }
            },
            children
        });

    return [
        gridLayoutFactory({
            slot: TableSlot.HEADER,
            children: tableHeadersFactory()
        }),
        createEntity({
            type: WidgetType.TABLE_ROW,
            props: merge({}, rowPropsDefault, {
                style: {
                    hover: {
                        bgColor: 'rgba(245, 252, 255, 1)'
                    },
                    select: {
                        bgColor: 'rgba(245, 252, 255, 1)'
                    }
                },
                border: {
                    isDisplayed: true,
                    color: 'rgba(226, 226, 226, 1)'
                }
            }),
            children: [
                gridLayoutFactory({
                    children: tableCellsFactory()
                })
            ]
        }),
        createEntity({
            type: WidgetType.TABLE_PAGINATOR,
            props: merge({}, paginatorPropsDefault, {
                slot: TableSlot.FOOTER,
                style: {
                    fontSize: 'var(--font-size-smaller)',
                    color: 'rgba(0, 0, 0, 0.5)',
                    bgColor: 'transparent',
                    bgColorActive: 'rgba(0, 0, 0, 0.5)',
                    height: 'var(--font-size-smaller)',
                    width: '0rem',
                    gap: '0rem'
                }
            })
        })
    ];
};

/**
 * @param {string[]} metrics
 * @param {{name: string, type: string}[]} schema
 * @return {string[]}
 */
export const sortMetricsByType = (metrics, schema) =>
    metrics.sort((aName, bName) => {
        const [{ type: metricTypeA }] = schema.filter(({ name }) => name === aName);
        const [{ type: metricTypeB }] = schema.filter(({ name }) => name === bName);

        if (metricTypeA === FieldDataType.VARCHAR && metricTypeB !== FieldDataType.VARCHAR) {
            return -1;
        }
        if (metricTypeA !== FieldDataType.VARCHAR && metricTypeB === FieldDataType.VARCHAR) {
            return 1;
        }
        if (hasFieldNumberType(metricTypeA) && hasFieldNumberType(metricTypeB) === false) {
            return -1;
        }
        if (hasFieldNumberType(metricTypeA) === false && hasFieldNumberType(metricTypeB)) {
            return 1;
        }
        return 0;
    });

/**
 * @param {any[]} arr
 * @param {any} value
 * @param {boolean} [mayContainMultiple]
 * @param {boolean} [shouldFilterSingleValue=true]
 * @return {any[]}
 */
export const filterOrExtendWith = (arr, value, mayContainMultiple, shouldFilterSingleValue = true) => {
    const hasValue = arr.includes(value);

    if (mayContainMultiple) {
        return hasValue ? arr.filter((item) => item !== value) : [...arr, value];
    }
    return hasValue && shouldFilterSingleValue ? [] : [value];
};
