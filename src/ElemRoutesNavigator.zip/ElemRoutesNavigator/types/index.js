/**
 * @typedef {import('./ElemRoutesNavigator').TInstance} TInstance
 * @type {TInstance}
 */
export const ElemInstanceTypeDescriptor = undefined;

/**
 * @typedef {import('./SettingsPanel').TInstance} TInstance
 * @type {TInstance}
 */
export const PanelInstanceTypeDescriptor = undefined;
