export const DatasetPanelMixin = {};

export default DatasetPanelMixin;
